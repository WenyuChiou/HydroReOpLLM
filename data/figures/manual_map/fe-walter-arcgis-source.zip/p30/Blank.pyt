class Toolbox:
    def __init__(self):
        self.label='Blank'
        self.alias='blank'
        self.tools=[]
