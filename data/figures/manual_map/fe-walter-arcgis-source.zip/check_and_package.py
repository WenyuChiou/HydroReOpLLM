from pathlib import Path
from hashlib import sha256
from collections import Counter
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree
from PIL import Image
import json

root=Path(__file__).resolve().parent
parent=root.parent/'2026-10-21-colorbar-boundaries-v3'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=etree.parse(str(parent/'native/commondata/pictures/layout-numbered.svg'))
after=etree.parse(str(root/'native/commondata/pictures/layout-numbered.svg'))
for key in ['renderer-colorbar','right-map-precipitation-colorbar','subcatchment-labels']:
    assert etree.tostring(before.xpath(f'//*[@id="{key}"]')[0])==etree.tostring(after.xpath(f'//*[@id="{key}"]')[0]),key
legend=after.xpath('//*[@id="study-area-legend"]')[0]
river=next(x for x in legend if etree.QName(x).localname=='text' and x.text=='Rivers')
line=next(x for x in legend if etree.QName(x).localname=='line' and x.get('stroke')=='#0096E0')
assert abs(float(river.get('y'))-float(line.get('y1'))-7.12)<0.01
actual=etree.parse(str(root/'study-area-v4.svg'))
fonts=Counter(actual.xpath('//@font-family'))
assert all('Arial' in family for family in fonts)
texts=[t.strip() for t in actual.xpath('//*[local-name()="text"]//text()')]
expected={f'U{i}' for i in range(1,8)}|{f'D{i}' for i in range(1,10)}|{'L1','L2'}
assert expected.issubset(set(texts))
assert 'Rivers' in texts
assert all(x in ''.join(texts) for x in ['01447500','01447800','01449000'])
image=Image.open(root/'study-area-v4.png').convert('RGB')
image.resize((1600,835),Image.Resampling.LANCZOS).save(root/'preview-1600.png')
image.resize((680,355),Image.Resampling.LANCZOS).save(root/'preview-180mm-at-96dpi.png')
word=root.parents[2]/'writing-review-2026-10-16/full-manuscript-20261019/word'
expected_docs={'MANUSCRIPT_FULL.docx':'aad1bcc70142a8610f8362ae324ce712b551ef0ade9a9404b934aaa094bb0b51',
               'OUTLINE_CONCISE.docx':'083e7ad8cc0ddb23b3abe0af98ad4b8e17a26cec3cf7f9fa9508c4b38aba440f',
               'SUPPLEMENT.docx':'b818ea24622f9ef4e53b8929ee1dc7cc589b7a02e4a1710aa3928f7e7386b242'}
docs={k:digest(word/k)==v for k,v in expected_docs.items()}
assert all(docs.values())
build=json.loads((root/'BUILD_REPORT.json').read_text())
report={'fonts':dict(fonts),'river_legend_present':True,'river_color':'#0096E0',
        'river_layers_changed':len(build['river_changes']),'label_count':18,'USGS_IDs_preserved':True,
        'colorbar_and_number_labels_byte_identical':True,'data_files_unchanged':build['data_files_changed']==[],
        'canonical_DOCX_unchanged':docs,'PNG_sha256':digest(root/'study-area-v4.png'),
        'SVG_sha256':digest(root/'study-area-v4.svg')}
(root/'CHECK_REPORT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
readme='''# River color and legend revision (candidate v4)

Authored river lines in the main study-area map, reservoir inset, and Delaware River Basin overview now use bright blue (#0096E0). Existing channel widths, white casings, river geometry, reservoir polygon fills, precipitation values/palette, watershed styles, map extent, and numbered labels are preserved. A matching Rivers line sample was added to the legend. The legend is 16.91 SVG pixels taller to accommodate the new row; its width and font size are unchanged.

Open native/project/river-legend-study-area.aprx in ArcGIS Pro 3.2. River colors are editable native layer symbology; the legend and other annotations are editable in native/commondata/pictures/layout-numbered.svg. For ArcPy export, set the working directory to native/project to resolve the relative SVG path. If needed, relink the single picture element to that SVG. This relative-path structure was tested in v1; opening the GUI on a different computer has not been tested.

The native project was saved, reopened, and exported to PNG and SVG. Source hashes, fonts, labels, river legend, and preserved colorbar were checked. No model simulation, calibration, LLM call, or new PDF was produced. The manuscript, English outline, and supplement remain unchanged. Earlier candidates and their failure histories remain in adjacent folders.

Boundary colors remain orange-brown for the full study watershed, purple-red for the F. E. Walter upstream watershed, and grey with a white casing for internal subbasin boundaries. The precipitation colorbar remains below the right-hand map only. Its 1996-2025 period is distinct from the reservoir-operation comparison period.

Attribution: USGS monitoring locations and preserved NLDI geometry; NHDPlus HR VPU0204 (March 2022); Daymet V4 R1 (https://doi.org/10.3334/ORNLDAAC/2129); Esri World Terrain Base, World Terrain Reference, and World Hillshade. Original service references remain in the native GIS source. Source basemap hydrography is retained as provided by the basemap service; the brighter color applies to the editable thematic river layers listed in BUILD_REPORT.json.
'''
(root/'README.md').write_text(readme,encoding='utf-8')
files=[p for p in (root/'native/commondata').rglob('*') if p.is_file() and not p.name.endswith('.lock')]
files.append(root/'native/project/river-legend-study-area.aprx')
for name in ['README.md','BUILD_REPORT.json','CHECK_REPORT.json','SUBCATCHMENT_LABEL_CROSSWALK.csv',
             'revise_rivers.py','check_and_package.py','study-area-v4.png','study-area-v4.svg']:
    files.append(root/name)
manifest={'parent_candidate':str(parent),'parent_PNG_sha256':digest(parent/'study-area-v3.png'),
          'files':[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]}
(root/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
bundle=root/'study-area-v4-editable-source.zip'
with ZipFile(bundle,'w',ZIP_DEFLATED) as archive:
    for p in files+[root/'SOURCE_MANIFEST.json']:
        archive.write(p,p.relative_to(root).as_posix())
with ZipFile(bundle) as archive:
    assert archive.testzip() is None
    for record in manifest['files']:
        assert sha256(archive.read(record['path'])).hexdigest()==record['sha256']
report['ZIP_sha256']=digest(bundle)
(root/'DELIVERY_RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
