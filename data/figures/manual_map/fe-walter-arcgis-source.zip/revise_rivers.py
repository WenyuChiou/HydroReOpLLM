from pathlib import Path
from hashlib import sha256
from lxml import etree
import json
import os
import shutil
import arcpy

ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent/'2026-10-21-colorbar-boundaries-v3'
NATIVE=ROOT/'native'
SVG='http://www.w3.org/2000/svg'
BLUE=[0,150,224,100]
HEX='#0096E0'
if NATIVE.exists():
    for name in ['project/right-colorbar-study-area.aprx','commondata/pictures/layout-numbered.svg']:
        assert sha256((NATIVE/name).read_bytes()).digest()==sha256((PARENT/'native'/name).read_bytes()).digest(),name
    assert not (NATIVE/'project/river-legend-study-area.aprx').exists()
    print('REUSING_VERIFIED_UNMODIFIED_COPY_AFTER_LAYER_NAME_CORRECTION',flush=True)
else:
    shutil.copytree(PARENT/'native',NATIVE)
shutil.copy2(PARENT/'SUBCATCHMENT_LABEL_CROSSWALK.csv',ROOT/'SUBCATCHMENT_LABEL_CROSSWALK.csv')
os.chdir(str(NATIVE/'project'))
project=arcpy.mp.ArcGISProject(str(NATIVE/'project/right-colorbar-study-area.aprx'))
targets={'Lehigh River','Connected stream network',
         'Delaware River mainstem','Selected connected DRB tributary routes (NLDI)'}
changes=[]
for m in project.listMaps():
    for layer in m.listLayers():
        if layer.name not in targets:
            continue
        sym=layer.symbology
        if sym.renderer.type!='SimpleRenderer':
            raise RuntimeError('Unexpected renderer: '+layer.name)
        before=sym.renderer.symbol.color
        sym.renderer.symbol.color={'RGB':BLUE}
        layer.symbology=sym
        changes.append({'map':m.name,'layer':layer.name,'before':before,'after':HEX})
assert targets=={x['layer'] for x in changes}
assert {'F. E. Walter Reservoir inset','F. E. Walter Detail','Delaware River Basin Overview'}=={x['map'] for x in changes}
overlay_path=NATIVE/'commondata/pictures/layout-numbered.svg'
tree=etree.parse(str(overlay_path))
legend=tree.xpath('//*[@id="study-area-legend"]')[0]
for node in legend.xpath('./*[local-name()="text"]'):
    if node.text=='Streamflow gauges':
        node.text='Legend'
shift=16.91
for node in list(legend):
    tag=etree.QName(node).localname
    if tag=='rect':
        node.set('height',str(float(node.get('height'))+shift))
    elif tag=='text' and float(node.get('y','0'))>=120:
        node.set('y',str(float(node.get('y'))+shift))
    elif tag=='line' and float(node.get('y1','0'))>=120:
        for key in ['y1','y2']:
            node.set(key,str(float(node.get(key))+shift))
    elif tag=='path' and node.get('fill')=='#17263b':
        node.set('transform',f'translate(0 {shift}) scale(1,0.89)')
for color,width in [('#FFFFFF',2.8*100/72),(HEX,1.8*100/72)]:
    etree.SubElement(legend,'{%s}line'%SVG,{'x1':'0','x2':'22','y1':'105.91','y2':'105.91',
                                            'stroke':color,'stroke-width':str(width)})
text=etree.SubElement(legend,'{%s}text'%SVG,{'x':'32','y':'113.03','font-family':'Arial','font-size':'21'})
text.text='Rivers'
tree.write(str(overlay_path),xml_declaration=True,encoding='utf-8')
layout=project.listLayouts()[0]
layout.listElements('PICTURE_ELEMENT')[0].sourceImage='../commondata/pictures/layout-numbered.svg'
target=NATIVE/'project/river-legend-study-area.aprx'
project.saveACopy(str(target))
del project
project=arcpy.mp.ArcGISProject(str(target))
assert not project.listBrokenDataSources()
layout=project.listLayouts()[0]
print(json.dumps({'river_changes':changes,'legend_added':'Rivers','legend_height_added_svg_px':shift},indent=2),flush=True)
layout.exportToSVG(str(ROOT/'study-area-v4.svg'),resolution=180,embed_fonts=True)
print('SVG_EXPORTED',flush=True)
layout.exportToPNG(str(ROOT/'study-area-v4.png'),resolution=300)
print('PNG_EXPORTED',flush=True)
changed=[]
for p in (PARENT/'native/commondata').rglob('*'):
    if p.is_file() and p.suffix.lower() not in {'.svg','.lock'}:
        q=NATIVE/'commondata'/p.relative_to(PARENT/'native/commondata')
        if sha256(p.read_bytes()).digest()!=sha256(q.read_bytes()).digest():
            changed.append(str(p))
assert not changed,changed
report={'tool':arcpy.GetInstallInfo(),'parent_PNG_sha256':sha256((PARENT/'study-area-v3.png').read_bytes()).hexdigest(),
        'river_changes':changes,'legend_label':'Rivers','river_color':HEX,
        'river_widths_and_white_casings_unchanged':True,'legend_height_added_svg_px':shift,
        'boundary_styles_and_right_colorbar_unchanged':True,'data_files_changed':changed,
        'saved_project_reopened':True,'no_research_execution':True,'no_new_PDF':True}
(ROOT/'BUILD_REPORT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('BUILD_COMPLETE',flush=True)
