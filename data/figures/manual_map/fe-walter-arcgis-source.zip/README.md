# F. E. Walter study area

Open project/study-area.aprx in ArcGIS Pro. The watershed, subbasin, river, reservoir and station layers are editable. Legend labels, connectors, scale bars and the colorbar are in commondata/pictures/layout_overlay.svg. Terrain basemap services require internet access.

The study watershed drains to Lehighton (USGS 01449000); its F. E. Walter portion drains to the dam. Seven accepted upper subbasins and nine lower spatial units are retained. Downstream calibration and simulation remain future work. No hydrology, reservoir operation or LLM simulation was run.

Precipitation is unchanged Daymet V4 R1 mean annual precipitation, 1996–2025. Sources: USGS monitoring locations 01447500, 01447800 and 01449000; preserved NLDI geometry; NHDPlus HR VPU0204 March 2022; Daymet V4 R1 (https://doi.org/10.3334/ORNLDAAC/2129); Esri terrain basemaps. The captions define outlets and gauge positions. Exact data and export hashes are in source-manifest.json.

When editing the overlay programmatically, retain the default SVG namespace. ArcGIS Pro 3.2 did not display an ns0-prefixed test overlay; the corrected default-namespace edit was saved, reopened and rendered successfully.
