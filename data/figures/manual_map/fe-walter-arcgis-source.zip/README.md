# River color and legend revision (candidate v4)

Authored river lines in the main study-area map, reservoir inset, and Delaware River Basin overview now use bright blue (#0096E0). Existing channel widths, white casings, river geometry, reservoir polygon fills, precipitation values/palette, watershed styles, map extent, and numbered labels are preserved. A matching Rivers line sample was added to the legend. The legend is 16.91 SVG pixels taller to accommodate the new row; its width and font size are unchanged.

Open native/project/river-legend-study-area.aprx in ArcGIS Pro 3.2. River colors are editable native layer symbology; the legend and other annotations are editable in native/commondata/pictures/layout-numbered.svg. For ArcPy export, set the working directory to native/project to resolve the relative SVG path. If needed, relink the single picture element to that SVG. This relative-path structure was tested in v1; opening the GUI on a different computer has not been tested.

The native project was saved, reopened, and exported to PNG and SVG. Source hashes, fonts, labels, river legend, and preserved colorbar were checked. No model simulation, calibration, LLM call, or new PDF was produced. The manuscript, English outline, and supplement remain unchanged. Earlier candidates and their failure histories remain in adjacent folders.

Boundary colors remain orange-brown for the full study watershed, purple-red for the F. E. Walter upstream watershed, and grey with a white casing for internal subbasin boundaries. The precipitation colorbar remains below the right-hand map only. Its 1996-2025 period is distinct from the reservoir-operation comparison period.

Attribution: USGS monitoring locations and preserved NLDI geometry; NHDPlus HR VPU0204 (March 2022); Daymet V4 R1 (https://doi.org/10.3334/ORNLDAAC/2129); Esri World Terrain Base, World Terrain Reference, and World Hillshade. Original service references remain in the native GIS source. Source basemap hydrography is retained as provided by the basemap service; the brighter color applies to the editable thematic river layers listed in BUILD_REPORT.json.
