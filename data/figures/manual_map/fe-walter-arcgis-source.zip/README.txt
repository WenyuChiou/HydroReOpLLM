F. E. Walter ArcGIS source

Open FE_Walter_DRB_manual_v9.aprx in ArcGIS Pro. The archive contains all local
vector and raster dependencies. Esri World Terrain Reference, World Terrain Base,
and World Hillshade remain online service layers and require network access.

The project has three maps (CONUS, Delaware River Basin, and F. E. Walter detail)
and one 16 x 9 inch export layout. The Daymet raster contains the frozen 1996-2025
mean annual precipitation source; symbology stretches 1300-1550 mm/year with a
256-sample cream-jade-teal-indigo ramp. Actual raster values span
1318.8409423828-1539.0002441406 mm/year.
